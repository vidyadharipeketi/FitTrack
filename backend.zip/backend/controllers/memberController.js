const Member = require("../models/Member");

// ================= ADD MEMBER =================
const addMember = async (req, res) => {
  try {
    const {
      fullName,
      email,
      phone,
      gender,
      age,
      membershipPlan
    } = req.body;

    // Check required fields
    if (
      !fullName ||
      !email ||
      !phone ||
      !gender ||
      !age ||
      !membershipPlan
    ) {
      return res.status(400).json({
        message: "Please fill all required fields"
      });
    }

    // Check if member already exists
    const existingMember = await Member.findOne({ email });

    if (existingMember) {
      return res.status(400).json({
        message: "Member already exists"
      });
    }

    // Create member
    const member = await Member.create({
      fullName,
      email,
      phone,
      gender,
      age,
      membershipPlan
    });

    res.status(201).json({
      success: true,
      message: "Member added successfully",
      member
    });

  } catch (error) {
    console.log(error);

    res.status(500).json({
      message: "Server Error"
    });
  }
};

// ================= GET ALL MEMBERS =================
const getAllMembers = async (req, res) => {
  try {
    const members = await Member.find();

    res.status(200).json({
      success: true,
      count: members.length,
      members
    });

  } catch (error) {
    console.log(error);

    res.status(500).json({
      message: "Server Error"
    });
  }
};
// ================= UPDATE MEMBER =================
const updateMember = async (req, res) => {
  try {
    const { id } = req.params;

    const updatedMember = await Member.findByIdAndUpdate(
      id,
      req.body,
      { new: true }
    );

    if (!updatedMember) {
      return res.status(404).json({
        message: "Member not found"
      });
    }

    res.status(200).json({
      success: true,
      message: "Member updated successfully",
      updatedMember
    });

  } catch (error) {
    console.log(error);

    res.status(500).json({
      message: "Server Error"
    });
  }
};

module.exports = {
  addMember,
  getAllMembers,
  updateMember
};
