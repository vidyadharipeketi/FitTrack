const mongoose = require("mongoose");

const memberSchema = new mongoose.Schema(
{
    fullName:{
        type:String,
        required:true
    },

    email:{
        type:String,
        required:true,
        unique:true
    },

    phone:{
        type:String,
        required:true
    },

    gender:{
        type:String,
        required:true
    },

    age:{
        type:Number,
        required:true
    },

    membershipPlan:{
        type:String,
        required:true
    },

    joiningDate:{
        type:Date,
        default:Date.now
    },

    status:{
        type:String,
        default:"Active"
    }

},
{timestamps:true}
);

module.exports = mongoose.model("Member", memberSchema);