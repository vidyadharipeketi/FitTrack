const express = require("express");
const router = express.Router();

router.get("/", (req, res) => {
  res.send("GET route works");
});

router.put("/test", (req, res) => {
  res.send("PUT route works");
});

module.exports = router;